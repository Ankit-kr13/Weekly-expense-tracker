package com.example.personal_exp

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
